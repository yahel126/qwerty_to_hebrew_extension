chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "convertToHebrew",
    title: "Convert QWERTY to Hebrew",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "convertToHebrew") {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: convertSelectionToHebrew
    });
  }
});

chrome.commands.onCommand.addListener((command) => {
  if (command === "convert-qwerty-hebrew") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        function: convertSelectionToHebrew
      });
    });
  }
});

function convertSelectionToHebrew() {
  const qwertyToHebrew = {
    'a': 'ש','b': 'נ','c': 'ב','d': 'ג','e': 'ק','f': 'כ','g': 'ע','h': 'י',
    'i': 'ן','j': 'ח','k': 'ל','l': 'ך','m': 'צ','n': 'מ','o': 'ם','p': 'פ',
    'q': '/','r': 'ר','s': 'ד','t': 'א','u': 'ו','v': 'ה','w': '\'','x': 'ס',
    'y': 'ט','z': 'ז',',': 'ת','.': 'ץ',';': 'ף',' ': ' ','"': ',', '/': '.'
  };

  const active = document.activeElement;

  if (active && (active.tagName === 'TEXTAREA' || (active.tagName === 'INPUT' && active.type === 'text'))) {
    const start = active.selectionStart;
    const end = active.selectionEnd;
    const selectedText = active.value.substring(start, end);

    const converted = selectedText.split('').map(char => qwertyToHebrew[char.toLowerCase()] || char).join('');
    const before = active.value.substring(0, start);
    const after = active.value.substring(end);

    active.value = before + converted + after;
    active.setSelectionRange(start, start + converted.length);
  } else {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const range = selection.getRangeAt(0);
    const text = selection.toString();

    const converted = text.split('').map(char => qwertyToHebrew[char.toLowerCase()] || char).join('');

    const span = document.createElement("span");
    span.textContent = converted;
    range.deleteContents();
    range.insertNode(span);
  }
}
