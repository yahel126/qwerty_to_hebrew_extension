// (empty for now – all logic is handled in the background script)
